If your publication does not function flawlessly, this can be caused
e.g. by a false combination of selection options in Wizard.
Unfortunately we cannot avoid this on the whole through query mechanisms
because in this way we would restrict functionality of the Wizard. It
may be the case that you want to publish parts of your model once
locally on ISS (on your PC) and another time on an Apache Webserver in
LAN etc. Therefore we recommend that you consult the articles summarised
here based on troubleshooting in the log file.

<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>