Automatic synchronisation of tasks is also supported (initiated when a
task is being displayed in p4b in Task View tab in the repository or
modeller). The automatic synchronisation behaviour can be selected in
the Client settings in Views tab. Automatic synchronization can be
turned off or enabled in two ways: data will be loaded from exchange
every time a task is being listed, or data are only loaded the first
time the task is being listed (counted from login).

![](//images.ctfassets.net/utx1h0gfm1om/4VifiW0x0sWiCY4SaqaMSY/f5133d4f93b4334689e9956a524122fc/328857.png)
<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>