If you want to apply a "\*.vbs" script for your diagrams, you can do it
with a special Wizard:

![](//images.ctfassets.net/utx1h0gfm1om/5ZyxRPbaGAuUSw4OImeMk4/aae18ba6efd4c34c3b49e14b011ff82c/329600.png)

In the script window you can first choose the script in "\*.vbs" format
and if necessary create the backup copies of the changed diagrams.

![](//images.ctfassets.net/utx1h0gfm1om/2MpZqd7LM4SweEoYkcsK0K/c2b2466f2ea0e6f9438550be4f8daf72/329165.png)

In the next step you can choose stencils (.vss) and templates (.vst),
where the script should be applied.

![](//images.ctfassets.net/utx1h0gfm1om/4q8sq3c2qkKkIyiQ82K048/da22c7f422188a4183f88201729225fb/329588.png)

And then the diagrams that you want to update with the script.

![](//images.ctfassets.net/utx1h0gfm1om/4p4ijaeysUIeGWIGgsyc8I/3221fa1eb6df2fbf7d27a6cebdba6d9b/329594.png)

 


<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>