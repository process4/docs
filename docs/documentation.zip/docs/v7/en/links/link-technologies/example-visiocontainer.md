The Visio container technology works for special Visio container shapes.

![](//images.ctfassets.net/utx1h0gfm1om/4LHiNqz008Cw4SeyQ2GkeK/1cb03518f8da5db8fe9316df01d5867c/328814.png)

When this technology is enabled between classes "C" and "A", objects of
these classes are linked to each other, if "A" is a container shape and
contains the object "C".

   
![](//images.ctfassets.net/utx1h0gfm1om/1rcHRz4fUcgwqUW6u44eem/0482766bf39555b0a3bc5b31b3fe1473/328774.png)

<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>