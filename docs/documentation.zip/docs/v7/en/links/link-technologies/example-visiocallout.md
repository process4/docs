The VisioCallout technology works for special Visio callout shapes.

![](//images.ctfassets.net/utx1h0gfm1om/ORgJeMGwIEqcGO8cwYaw4/c821a7b1a4df9de582079007d9c9f706/328799.png)

When this link technology is enabled for the classes "A" and "C",
objects of these classes are linked together, if "C" is a callout shape
for "A".
<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>