The Import Export Manager can be selected in the process4.biz menu under
the menu item Extensions:

***process4.biz -&gt; Extensions -&gt; Import-Export Manager ...*** 

You need to be logged into one of the databases. The graphical user
interface is presented in the language that you have defined in the
global options of process4.biz, found under the Visio menu item
Process4.biz → Client Preferences .... in the option field with the same
name. In the selection field below "Define language for the display of
model contents" you can select the language in which the contents of the
database are to be displayed and exported or imported.

Select the desired process and click on the ***Next*** button.

![](//images.ctfassets.net/utx1h0gfm1om/2vgdcDl15akGSyKM48CuSM/3e236342244a683e42c371d172044773/329543.png)


<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>