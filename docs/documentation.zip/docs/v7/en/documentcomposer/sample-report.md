This chapter shows some excerpts from a sample report with object-based
content, to illustrate how the final report looks like. The report is
based on the examples from the previous chapters.

![](//images.ctfassets.net/utx1h0gfm1om/6EZiy96zpCYCgi6sQmmmqY/f4c2871c46ebfbf55d12044e541e8e31/329042.png)

![](//images.ctfassets.net/utx1h0gfm1om/2cyvqYxrIAukWoaaowI4ek/4c6dbdcab5c97b09b41b5538b9ac5a2c/329040.png)

<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>