To include special tags in the Document Composer user has to select Word
template with corresponding tags &lt;P4B\_ATTRIBUTE\_\*\*\*&gt; in it.
For example &lt;P4B\_ATTRIBUTE\_TAG&gt;
&lt;P4B\_ATTRIBUTE\_DescriptionTag&gt; and
&lt;P4B\_ATTRIBUTE\_LinkTag&gt; are added to the template.

![](//images.ctfassets.net/utx1h0gfm1om/7ztDUbiRaMsO0O2Cq2C2iM/7b646b01adc703b44bfbf18413ae2f9f/329646.png)

For that template, the “Special &lt;tags&gt;” tab is active and all tags
from the template are listed there. To fill the column “Objects” you
need to click button “Fill the tag value” and choose the parameters for
special tag.

![](//images.ctfassets.net/utx1h0gfm1om/cZdetU5EUSIgwKkcYCyUM/2036e34f1199154158f3eb331f0901b2/329659.png)

Type of source data can be diagram, object or query. Also for selected
type of source data, the source data and source value has to be selected
from the drop-down list.

![](//images.ctfassets.net/utx1h0gfm1om/EgHD78ts8C2CCOM2YEO6w/90369173050130124e353827aa050f82/329666.png)

<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>