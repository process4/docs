

Gesteuert wird die Anzeige des Krümelpfads durch die folgenden Einträge
in der *main.css*:

![](//images.ctfassets.net/utx1h0gfm1om/38dnvurJ6Uc8AQesEgGI4G/d8de06b0121f65bb037c86c958747c1d/1017397.png)

Dauerhaft sichtbar wird die Leiste durch die Folgende Änderung an
„max-width“:

![](//images.ctfassets.net/utx1h0gfm1om/1dPvnlIOBm66QKOeOKGWok/6d1c839bc99c83ecda507ebeea378957/1017398.png)

Bitte die *main.css* entsprechend anpassen.

**main.css Pfad**

``` java
C:\\Programme\process4biz\Extensions\Publisher Server\config\styles\Process4.biz [default]\css\
```

<div class="warning">
**Achtung: Nach den Änderungen, muss die Web-Publikation neu erstellt
werden.**
  </div>


<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>