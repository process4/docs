Wenn Ihre Publikation nicht einwandfrei funktioniert hat, so kann das
z.B. an einer falschen Kombination von Auswahloptionen im Wizard liegen.
Dies können wir leider nicht umfassend durch Abfragemechanismen
abfangen, da wir den Wizard ansonsten in der Funktionalität einschränken
würden. So kann es sein, dass Sie Teile Ihres Modells einmal lokal auf
den IIS (auf Ihrem PC) publizieren wollen und ein anderes Mal Teile des
Modells auf einen Apache Webserver im LAN, etc. Wir empfehlen Ihnen
daher, auf Basis der Fehlermeldung in der Logdatei die hier
zusammengefassten Artikel zu konsultieren.

<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>