

### Problem

Sie haben eine große Shape, auf der Sie mehrere kleine Shapes platziert
haben. Wenn Sie versuchen, die kleinen Shapes mit anderen Shapes zu
verbinden, verläuft der Verbinder um die große Shape herum, anstatt
Anfang und Ende direkt miteinander zu verbinden.

![](//images.ctfassets.net/utx1h0gfm1om/6Io09lGpZSO4e2KqKyoOus/8ffb2a7f059158d6dfeacc605055da48/1018811.png)

### Lösung

Wechseln Sie mit **Datei -&gt; Optionen -&gt; Erweitert -&gt; In
Entwicklermodus ausführen** in den Entwicklermodus. Wählen Sie die große
Shape aus und öffnen Sie Format -&gt; Verhalten -&gt; Platzierung.
Wählen Sie unter Platzierungsverhalten "Nicht rundherumlegen" aus.

![](//images.ctfassets.net/utx1h0gfm1om/6hnJCk57gcMeOkCUmuuyM0/d3170fa7f7bfe831d865d5e2c46661c2/1018807.png)

Wenn die große Shape ein p4b-Objekt ist und Sie es von einem Stencil aus
verwenden, macht es Sinn, diese Schritte auch für die Master-Shape
durchzuführen.


<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>