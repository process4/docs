### SharePoint Synchronisierung

Diese Erweiterung erlaubt den Nutzer die Synchronisierung mit SharePoint. Um SharePoint Synchronisierung zu nutzten, muss der Benutzer eine SharePoint Seite erstellen und Sie zu der Liste der SharePoint Seiten hinzufügen, die Synchronisierung konfigurieren und angeben welche Objekte und Eigenschaften synchronisiert werden müssen, die Richtung der Synchronisierung muss festgelegt werden. 
 

### SharePoin Synchronisierung nutzen

-   [SharePoint Site](sharepoint-seite)
-   [Diagram Storage](diagramm-speicher)
-   [Configure synchronization](synchronisierung-konfigurieren)
-   [Data Binding](datenbindung)

<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>