Automatische Synchronisierung der Tasks wird auch unterstützt (angefangen wenn das Task in p4b Task-Ansicht oder im Repository oder Modeler gezeigt wird). Automatische Synchronisierung kann in den GUI Einstellungen ausgewählt werden. 

![](//images.ctfassets.net/utx1h0gfm1om/4VifiW0x0sWiCY4SaqaMSY/f5133d4f93b4334689e9956a524122fc/328857.png)


Automatische Synchronisierung kann ein- oder ausgeschaltet werden auf 2 Arten: Daten werden aus dem Exchange jedes Mal wenn das Task gezeigt wird geladen oder nur das erste Mal (gezählt ab dem Login).

<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>