## Überblick
Jedes Datenobjekt kann verknüpfte Tasks haben. All diese Tasks haben Attribute (Ausführer, Beschreibung, Fälligkeitstermin etc.).  Jedes Task von p4b kann mit Task im Exchange verknüpft sein. Um dies zu tun, sollte die Exchange Integration erlaubt sein und korrekt konfiguriert sein. Auch der Ausführende sollte ein gültiger Exchange-Benutzer sein (seine E-Mail sollte im Exchange-Server spezifiziert sein).

<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>