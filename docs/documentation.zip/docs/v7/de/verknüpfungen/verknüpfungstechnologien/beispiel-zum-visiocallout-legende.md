

Die VisioCallout-Technologie funktioniert für spezielle Visio Legende
Shapes.  
![](//images.ctfassets.net/utx1h0gfm1om/Vh40W4iBoIi0SWIUOAuG2/8c3bed9844c864f6fd9272b251fbccfe/1018279.png)  
  
Wenn diese Verknüpfungstechnologie für die Klassen "A" und "C" aktiviert
ist, werden Objekte dieser Klassen miteinander verknüpft, wenn "C" ein
Legende-Shape für "A" ist.  
  
![](//images.ctfassets.net/utx1h0gfm1om/4dyzfuL4Ss8imcWoIKScEE/7ae6ab6d2cb87aa293673c3968a4928f/1018280.png)


<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>