

Die VisioContainer-Technologie funktioniert für spezielle Visio
Container Shapes.

![](//images.ctfassets.net/utx1h0gfm1om/2cpp9pSweME02W6YIcuUKi/57c842afbd36d150b3eef4520d28772c/1018281.png)  
Wenn diese Technologie zwischen Klassen "B" und "D" aktiviert ist,
werden Objekte dieser Klassen mit einander verknüpft, wenn "D" ein
Container-Shape ist und das Objekt "B" enthält.  
   
  
![](//images.ctfassets.net/utx1h0gfm1om/4WuPP0BuTewKaqU8guKUcM/bba28f4dcffe0a6478714249d49353bb/1018288.png)


<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>