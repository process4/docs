Um Special Tags im DocumentComposer zu inkludieren, muss der Benutzer eine Word Vorlage mit den entsprechenden Tabs verwenden &lt;P4B\_ATTRIBUTE\_\*\*\*&gt;. Zum Beispiel werden &lt;P4B\_ATTRIBUTE\_TAG&gt;
&lt;P4B\_ATTRIBUTE\_DescriptionTag&gt; und &lt;P4B\_ATTRIBUTE\_LinkTag&gt; zur Vorlage hinzugefügt. 

![image](//images.ctfassets.net/utx1h0gfm1om/6DTgzqyyeTU4AmXcfSgy5L/5056ae30584867cb9b69c3b8ff95a1ec/image.png)
 
Für diese Vorlage, wird der Special Tags Tab aktiviert und alle Tags aus der Vorlage werden aufgelistet. Um die Spalte Objekte zu füllen, müssen Sie den Button „Fill the tag value“ klicken und die Parameter für spezielle Tags auswählen. 


Art der Quelle können Diagramme, Objekte oder Abfragen sein. Auch für ausgewählte Arten von Daten, müssen die Daten und der Quellenwert aus der DropDown-Liste ausgewählt werden. 

<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>