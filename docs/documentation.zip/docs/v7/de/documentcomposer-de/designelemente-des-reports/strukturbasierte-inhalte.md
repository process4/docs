
Diese Art Dokumente mit dem DocumentComposer zu erstellen ermöglicht
eine fast automatische Generierung der Struktur. Diese wird anhand der
Diagramme und einer oder mehrerer Klassen von Objekten die auf diesem
liegen berechnet.

Dieser Screenshot zeigt die Struktur des Diagramms Qualitätsmanagement,
auf diesem Diagramm liegen Objekte der Klasse Prozess und Prozessgruppe.

Im Report soll nun automatisch eine Struktur aus den Prozessobjekten
erstellt werden. Dazu wähle ich zuerst das Startdiagramm, in diesem
Beispiel ist das Qualitätsmanagement. Dann wird definiert welche Klasse
als Struktur genommen werden soll. Sogleich berechnet der Wizard sie
Struktur und zeigt diese an. Auch werden die angehängten Diagramme
angezeigt und automatisch mit einigen anderen Attributen in den Report
eingefügt.

Hier nun noch ein Ausschnitt aus dem Report, der das Inhaltsverzeichnis
zeigt, dies zeigt die Struktur.


<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>