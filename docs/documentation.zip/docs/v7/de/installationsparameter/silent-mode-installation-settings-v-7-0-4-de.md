To generate the command required to install [process4.biz](https://process4.biz/) client (v.7.0.4) in silent mode open the link select installation options on the page.

[Silent mode install generation page](https://dev.process4.biz/confluence/pages/viewpage.action?pageId=100761734)
<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>