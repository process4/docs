
Ab dem process4.biz Release 5.3.1 ist es möglich, shape-spezifische
Attribute anzulegen (siehe Shape-spezifische
Attribute[).](http://www.prohttp//www.process4.biz/HelpContent/540/mod-hand/de/)

![](//images.ctfassets.net/utx1h0gfm1om/2WPpGWMrEsIOo46SEmqIKG/289f33b3293d9ed6f736e694d4591300/1018689.png)

Im QueryBuilder werden diese im speziellen Knoten ShapeDaten
zusammengefasst, können aber wie normale Attribute konfiguriert werden.

Für jedes Shape gibt es dann einen eigenen Zeileneintrag im Ergebnis,
welcher sich auf ein Attributeset eines Shapes bezieht.

![](//images.ctfassets.net/utx1h0gfm1om/StF0hysRKCA0gQaC4WE6U/837b0498b7434d3cad129859f2d61c64/1018693.png)


<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>