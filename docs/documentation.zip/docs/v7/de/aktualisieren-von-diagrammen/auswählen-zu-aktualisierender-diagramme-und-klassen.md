

Für alle oben beschriebenen Optionen kommen anschließend folgende
Dialogfenster.

1.  In der Diagramm-Liste können Sie die zu aktualisierenden Diagramme
    einzeln auswählen. Standardmäßig wird der Diagrammbaum dargestellt,
    aber Sie können die Sortierung auch nach Diagrammklasse und/oder nur
    Diagramme basierend auf einer speziellen Vorlage auswählen.
    Aktivieren von beiden Optionen gleichzeitig ist möglich.  
    ![](//images.ctfassets.net/utx1h0gfm1om/5nRHYt1QEo2GEka0mmkCuy/221bcb6e9c8d2dfffd44b32f03d138d4/1018832.png)
2.  In der Klassen-Liste können Sie Klassen von Objekten auswählen, die
    Sie aktualisieren möchten.  
    ![](//images.ctfassets.net/utx1h0gfm1om/6B76R7olQkw6qWqKKuSiKw/cf142a90e591c8f59b8e9bd2b416f7af/1018779.png)

Der Vorgang wird gestartet, wenn Sie auf die Schaltfläche ***Weiter***
klicken. Die Aktualisierung wird als zusätzlicher Visio-Prozess im
Hintergrund durchgeführt. Nach Beendigung der Aktualisierung können Sie
eventuelle Fehlermeldungen einsehen, wenn sie auf dem dann erscheinenden
Fenster auf die Schaltfläche ***Log*** klicken.


<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>