

Wenn Sie einen „\*.vbs" Script für Ihre Diagramme anwenden wollen,
können Sie es mit einem speziellen Wizard tun:

![](//images.ctfassets.net/utx1h0gfm1om/1Wpo34H8ssoQwSeGamCa8o/46f96b33251a3befac9244b861137e95/1018827.png)  
  
Im Skript-Fenster können Sie zunächst das Skript im „\*.vbs"-Format
auswählen und wenn nötig die Sicherungskopien der geänderten Diagramme
erstellen.

![](//images.ctfassets.net/utx1h0gfm1om/2dJhstWYrOm8awQGkUW2ac/429dbc1958dc5bb28e1b2e8c0b239800/1018823.png)

Im nächsten Schritt können Sie Schablonen (.vss) und Vorlagen (.vst)
auswählen, auf die das Skript angewendet werden soll.

![](//images.ctfassets.net/utx1h0gfm1om/5KrigSOQqk0Wy6GwQiu8GC/d9d5b7227524987d23623bd6984efef9/1018836.png)

Und dann die Diagramme, die Sie mit dem Script aktualisieren wollen.

<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>