
Im Eigenschaften-Dialog jedes Objekts kann der
Spracheigenschaften-Dialog angerufen werden, wenn Sie auf die kleine
Schaltfläche mit den drei Punkten
![](//images.ctfassets.net/utx1h0gfm1om/1feaW6gicYouaoYeo0yEGI/df6206203f98ede56005be497005995f/1017374.png) klicken,
die zwischen jedem markierten Attribut (links) und dessen zugehöriger
Ausprägung (rechts) eingeblendet wird.  
  
![](//images.ctfassets.net/utx1h0gfm1om/3R0hRGbV20ks0CE6iIW0O2/db7cd292a2a6157e0cde4fa2ca876613/1017457.png)

  
Im Dialogfenster für Sprachen Eigenschaften erscheinen links die
verfügbaren  
Sprachen, in der rechten Spalte können Sie die Begriffe übersetzen.  
Um ein ganzes Modell zu übersetzen, ist die Verwendung des
Excel-Import-Export  
& PowerPoint-Managers empfehlenswert, der als eigene Extension separat
lizenzierungspflichtig ist.  
  

![](//images.ctfassets.net/utx1h0gfm1om/11xED3i0KaqAqeWoOUEYOs/6387fd7ca208b4237b625679b780cbe8/1017472.png)


<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>