
In diesem Fenster können Sie die Datenobjekte und deren Attribute
auswählen, die im Report angezeigt werden sollen. Attribute werden nach
deren Attributgruppen gruppiert. Dies können Sie durch Auswählen der
gewünschten Klassen, Attributgruppen oder Attribute erreichen.

Wenn manche Klassen als grau markiert sind, dann sind dieser derzeit im
Report nicht vorhanden und können somit nicht für den Export ausgewählt
werden.

Sie können die Reihenfolge von Klassen in der Liste via ein Attribut "
Priorität" ändern (siehe [Anlegen eines Attributs](Anlegen_eines_Attributs)).

![](//images.ctfassets.net/utx1h0gfm1om/6v2BZ4MnEkSmc2Wki4sc4S/f6011d03d8744c293014922237d973b0/1017862.png)


<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>