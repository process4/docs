
Titelseite und Zusammenfassung des geöffneten Dokumentes basieren auf
der vordefinierten Word-Dokumentenvorlage (sehen Sie Dokumentenvorlage
für den WordReporter).  
Das auf Basis des Export-Vorganges automatisch generierte
Inhaltsverzeichnis listet die nach Word exportierten Diagramme und die
in den Diagrammen dargestellten Objekte in der Reihenfolge, die Sie
vorher definiert haben (Erweiterte Diagrammsortierung), auf. Ein
Ausschnitt von einem solchen Inhaltsverzeichnis ist im unten
dargestellten Bild zu sehen.  
![](//images.ctfassets.net/utx1h0gfm1om/2gs8eZ1W2AwQ2QukGgOgmG/e379d22d31ad90f3588c78f78283a9fa/1017868.png)   
  
Die folgenden Bilder zeigen die Darstellung von Diagrammen bzw.
Datenobjekten in MS Word, basierend auf den Formatierungseinstellungen
der Dokumentenvorlage. Wenn Diagramm-Attribute exportiert wurden, werden
Sie nach jedem Diagramm aufgelistet.  
![](//images.ctfassets.net/utx1h0gfm1om/2A2R5eR7aQEoU0casWuYyK/fd54fcbebca5c851bcd0a13efc2b6261/1017875.png)  
Je nachdem, welche Option Sie im Word Reporter Wizard ausgewählt haben,
werden Objekt-Eigenschaften entweder nach jedem Diagramm oder erst im
Anschluss an die Darstellung sämtlicher Diagramme aufgelistet.  
  
![](//images.ctfassets.net/utx1h0gfm1om/37mgigX4N2IyoSUgYYEe6A/d3590b1a338073209ca1e9cde2a94c33/1018661.png)  
  
Objekt- und Diagramm-Eigenschaften können auf Wunsch auch in
Tabellenform dargestellt werden, um die Übersichtlichkeit zu erhöhen
(siehe Einstellungen für die Publikation):  
![](//images.ctfassets.net/utx1h0gfm1om/1EihrSYCVKCmICAUIs8syS/c4f916b7d8837a5888737f9d55b466d0/1018667.png)  
  
Wenn Objekt- und Diagrammverknüpfungen exportiert wurden, kommen Sie im
Anschluss von Eigenschaften jedes Objektes. Verknüpfte Objekte sind nach
den Verknüpfungstypen sortiert. Klassen von Objekten sowie (wenn
vorhanden) Assoziationsobjekte sind auch aufgelistet. Wenn ein
verknüpftes Diagramm zu einer Diagramm-Klasse zugewiesen ist, wird diese
Klasse auch angezeigt. Falls verknüpfte Objekte und Diagramme im
Dokument vorhanden sind, können Sie via Maus-Klick darauf auf die
entsprechende Dokumentseite springen.  
  
![](//images.ctfassets.net/utx1h0gfm1om/47r3wNDSg8IK284iEqIa6K/66e96d9ddf479940e76f21fd2f550b87/1018651.png)
  
![](//images.ctfassets.net/utx1h0gfm1om/440pUVgfheGqACG48giqss/db7dd57ab0908af425b4f41b3fa23d27/1018656.png)  
Am Ende des Berichts befindet sich das Stichwortverzeichnis mit den
Namen aller Datenobjekte und Diagramme, die in dem generierten
Word-Report vorkommen:  
![](//images.ctfassets.net/utx1h0gfm1om/1aHDazX4OqYCMayo6kk2KK/9a069648b17802b8a1fa87a0c1efddeb/1017509.png)  
Durch dieses Verzeichnis wird das Auffinden gesuchter Objekte bzw.
Diagram me erleichtert und es vereinfacht Ihnen somit die Auswertung des
erstellten Berichts.


<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>