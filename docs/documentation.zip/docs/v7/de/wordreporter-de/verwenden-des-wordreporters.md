Der Word Reporter kann im Menüpunkt **Process4.biz** von Visio aus
gestartet werden, wenn Sie dort auf ***Erweiterungen*** klicken und
darunter die Option Word Reporter auswählen: ***Process4.biz
→ Erweiterungen → Word Reporter*** .  
Sie müssen sich zuvor in eine der Datenbanken eingeloggt haben. Die
grafische Benutzeroberfläche wird in derjenigen Sprache präsentiert, die
Sie im Rahmen der globalen Optionen von process4.biz, zu finden unter
dem Visio-Menüpunkt ***Process4.biz → Client Einstellungen …*** im
gleichnamigen Optionsfeld festgelegt haben. Im darunter liegenden
Auswahlfeld ***Sprache*** für die Anzeige von Modellinhalten bestimmen
Sie die Sprache, in welcher die Inhalte der Datenbank nach Microsoft
Word exportiert werden sollen.

Bevor Sie den Word Reporter starten, stellen Sie sicher, dass alle Word
Dokumente geschlossen sind, damit Sie mögliche Fehler vermeiden, die
auftreten können, w enn das Dokument während der Reporterstellung
bearbeitet wird.

<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>