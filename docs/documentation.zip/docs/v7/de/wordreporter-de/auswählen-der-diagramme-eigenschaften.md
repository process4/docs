Wenn die Option „Exportieren der Diagramme-Eigenschaften" ausgewählt
wurde (siehe Einstellungen für die Publikation), kommt im nächsten
Schritt ein Fenster für Auswahl der Diagramm-Attribute.
Diagramm-Attribute sind (wie Objekt-Attribute) nach Unit, und innerhalb
von Units nach Diagramm-Klassen sortiert (siehe [Klasse](Klasse)).
System Diagramm-Attribute sind orange markiert.

Benutzerdefinierte Attributgruppe und Attribute sind blau markiert und
können für eine Unit oder eine Diagramm-Klasse spezifisch sein. Wählen
Sie Diagramm Attribute aus, die im Word Bericht aufgelistet werden
sollen.  
  

![](//images.ctfassets.net/utx1h0gfm1om/1Qi061vejykY2iAYMUE4SK/763963b4115a3fbd72a955e4a664fadd/1017866.png)


<hr style="padding-top:2rem" />
<a href="https://github.com/process4/docs/issues" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm">Report an issue</a>
<a href="https://github.com/process4/docs" target="_blank" class="bgw btn btn-primary btn-lg shadow-sm" style="margin-left:10px;">View source code</a>